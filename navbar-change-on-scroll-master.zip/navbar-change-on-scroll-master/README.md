# Changing a navigation's style on scroll

These files are to compliment my video tutorial which you [you can find here](https://youtu.be/RxnV9Xcw914).

## How to use these files
If you are following along, I used Gulp for the live reloading and compiling Sass to CSS. 
To use the build, you need npm and gulp installed first.

Once they are installed, in the command line, first type in `npm install`.

When the installation is finished, type `gulp watch` to get started.
